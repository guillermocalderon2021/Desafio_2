<!--=============================================
=            Include JavaScript files           =
==============================================-->
<!-- MDBootstrap V5 -->
<script src="<?php echo SERVERURL; ?>vistas/js/mdb.min.js" ></script>

<!-- Ajax JS -->
<script src="<?php echo SERVERURL; ?>vistas/js/ajax.js" ></script>

<!-- General scripts -->
<script src="<?php echo SERVERURL; ?>vistas/js/main.js" ></script>