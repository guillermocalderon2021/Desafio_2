<footer class="footer bg-white">
    <div class="container">
        <div class="row">



            <div class="col-12 col-md-4 mb-4">
                <ul class="list-unstyled" >
                    <li><h5 class="font-weight-bold" ><i class="far fa-copyright"></i> <?php echo COMPANY." ".date("Y"); ?></h5></li>

                </ul>
            </div>
            <div class="col-12 col-md-4 mb-4">
                <ul class="list-unstyled" >
                    <li><h5 class="font-weight-bold" ><?php echo NOMBRES;?></h5></li>
                    <li><i class="bi bi-c-square-fill"></i> <?php echo CARNETS; ?></li>
                </ul>
            </div>

        </div>
    </div>
</footer>